=======================================
TEAM 7 PROUDLY PRESENTS:
Simulation Project - Part B
=======================================

How to operate our simulation:
1. Check requirements.txt file to see &
   install required packages' versions.
   You can quickly install it with:
   pip install -r requirements.txt
2. Run "run_me.py" file.
3. Enter the number of iterations you'd
   like to simulate.
4. See the new plot which just opened.
5. Say "WOW!".
6. Enjoy the data provided in Excel file
   you got in your active directory.
7. Grade with love.

=======================================
From Yours Truely,
TEAM 7 - Menny's Parents
Almog Asraf
Daniel Pidtylok
Nir Levanon
=======================================