# Global Parameters - Shown here to save code repetition
SIM_TIME = 91  # 13 weeks * 7 days in week
PACKAGE_INDEX = 1  # Setting counter for package id
# Given data
LOOPS = 50
AVERAGE_NO_PACKAGES = {1: [7, 3, 1], 2: [8, 2, 1.5], 3: [12, 4, 2], 4: [5, 1, 3], 5: [8, 3, 1], 6: [3, 1, 1.5]}